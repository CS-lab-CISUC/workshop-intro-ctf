# Challenge Description
> "An undocumented ghost claims to be stranded at Paris CDG airport. Exploit his OPSEC failures to prove he's lying and track his real digital escape route."
